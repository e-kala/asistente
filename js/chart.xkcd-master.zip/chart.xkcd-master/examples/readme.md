## Preview

https://timqian.com/chart.xkcd/example.html

## Try it yourself

1. clone this repo
1. `npm install`
2. `npm start`
