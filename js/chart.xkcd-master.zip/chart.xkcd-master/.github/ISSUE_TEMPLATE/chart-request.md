---
name: Chart request
about: Suggest a new chart type for chart.xkcd
title: "[new chart]: "
labels: new chart
assignees: ''

---

**Chart type**

**Example of how the chart looks in other chart libs**

- link

- screenshot

<!--
  To support us building this chart, please consider either
    - be a patron of timqian: patreon.com/timqian
    - fund this issue on issuehunt after you create it: issuehunt.io/r/timqian/chart.xkcd?tab=idle
>
