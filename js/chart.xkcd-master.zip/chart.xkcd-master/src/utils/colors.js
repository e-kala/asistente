// TODO: use: https://github.com/mrmrs/colors ?
// use: https://gui.apex.sh/
export default ['#dd4528', '#28a3dd', '#f3db52', '#ed84b5', '#4ab74e', '#9179c0', '#8e6d5a', '#f19839', '#949494'];
